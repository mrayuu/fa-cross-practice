import React, { useState } from 'react';
import { View, Text, TextInput, Button } from 'react-native';

const Third = ({ navigation, route }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');

  const handleAddContact = () => {
    if (name && phone) {
      const newContact = { id: Math.random().toString(), name, phone };
      route.params.addContact(newContact);
      navigation.popToTop();
    }
  };

  return (
    <View>
      <Text>  </Text>
      <Text>Добавление нового контакта</Text>
      <Text>  </Text>
      <TextInput
        placeholder="Введите имя"
        value={name}
        onChangeText={setName}
        style={{ borderBottomWidth: 1, marginVertical: 10 }}
      />
      <TextInput
        placeholder="Введите номер телефона"
        value={phone}
        onChangeText={setPhone}
        keyboardType="phone-pad"
        style={{ borderBottomWidth: 1, marginVertical: 10 }}
      />
      <Text>  </Text>
      <Button title="Добавить контакт" onPress={handleAddContact} />
      <Text>  </Text>
      <Button title="Назад" onPress={() => navigation.popToTop()} />
    </View>
  );
};

export default Third;
