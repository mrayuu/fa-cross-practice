import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import First from './screens/first';
import Second from './screens/second';
import Third from './screens/third';

const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

function StackNavigator() {
  return (
    <Stack.Navigator initialRouteName="First">
      <Stack.Screen name="Начало" component={First} />
      <Stack.Screen name="Второй" component={Second} />
      <Stack.Screen name="Третий" component={Third} />
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Stack">
        <Drawer.Screen name="Начало" component={StackNavigator} />
        <Drawer.Screen name="Второй" component={Second} />
        <Drawer.Screen name="Третий" component={Third} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

