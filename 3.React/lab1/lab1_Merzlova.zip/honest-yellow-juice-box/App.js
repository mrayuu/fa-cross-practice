import React from 'react';
import { StyleSheet, Text, View, Button, Image } from 'react-native';

const LotsOfStyles = () => {
    return (
        <View style={styles.container}>
            <Text style={styles.header}>Журнал Bright</Text>
            
            <View style={styles.contentContainer}>
                <Text style={styles.sectionTitle}>Путешествия</Text>
                <Image
                    source={{ uri: 'https://brightmagazine.ru/wp-content/uploads/2024/10/simon-maage-C9dhUVP-o6w-unsplash.jpg' }}
                    style={styles.image}
                />
                <Text style={styles.bigblack}>Пить или не пить в самолете, вот в чем вопрос</Text>
                <Text style={styles.smallblack}>
                    Со всеми нами случалось так, что мы приезжали в аэропорт вдохновленные, но в самолете начинали чувствовать усталость. Что же мы можем сделать, чтобы насладиться путешествием? Самый простой ответ специалистов: пить больше воды.
                </Text>
                <Button title="Читать далее" onPress={() => { alert('Читать далее!'); }} />
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        marginTop: 50,
        padding: 20,
    },
    header: {
        fontSize: 24,
        fontWeight: 'bold',
        textAlign: 'center',
        marginBottom: 20,
    },
    contentContainer: {
        backgroundColor: '#f0f0f0',
        padding: 15,
        borderRadius: 10,
    },
    sectionTitle: {
        fontSize: 18,
        color: 'blue',
        marginBottom: 10,
    },
    image: {
        width: '100%',
        height: 200,
        marginBottom: 10,
    },
    bigblack: {
        color: 'black',
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 5,
    },
    smallblack: {
        color: 'black',
        fontSize: 16,
        marginBottom: 5,
    },
    blue: {
        color: 'blue',
        fontSize: 16,
        marginBottom: 5,
    },
});

export default LotsOfStyles;
