import React from 'react';
import { View, Text, Button } from 'react-native';

const Second = ({ route, navigation }) => {
  const { contact } = route.params || {}; // Получаем данные контакта из параметров

  return (
    <View>
      <Text>  </Text>
      <Text>Это второй экран</Text>
      <Text>  </Text>
      {contact ? (
        <>
          <Text>Имя: {contact.name}</Text>
          <Text>Телефон: {contact.phone}</Text>
        </>
      ) : (
        <Text>Контакт не выбран</Text>
      )}
      <Text>  </Text>
      <Button title="Перейти на третий экран" onPress={() => navigation.navigate('Третий')} />
      <Text>  </Text>
      <Button title="Назад" onPress={() => navigation.goBack()} />
    </View>
  );
};

export default Second;
