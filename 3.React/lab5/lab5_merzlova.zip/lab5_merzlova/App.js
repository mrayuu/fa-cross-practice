import React, { useRef, useEffect } from "react";
import {
  SafeAreaView,
  ScrollView,
  Text,
  StyleSheet,
  View,
  ImageBackground,
  Animated,
  useWindowDimensions,
  TouchableOpacity
} from "react-native";


const images =  [
  'https://eda.ru/images/RecipeStep/434x295/brauni-brownie_20955_step_1.jpg', 
  'https://eda.ru/images/RecipeStep/434x295/brauni-brownie_20955_step_2.jpg', 
  'https://eda.ru/images/RecipeStep/434x295/brauni-brownie_20955_step_3.jpg', 
  'https://eda.ru/images/RecipeStep/434x295/brauni-brownie_20955_step_4.jpg', 
  'https://eda.ru/images/RecipeStep/434x295/brauni-brownie_20955_step_5.jpg', 
  'https://eda.ru/images/RecipeStep/434x295/brauni-brownie_20955_step_6.jpg', 
];

const App = () => {
  const scrollX = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current; 
  const fadeButtonAnim = useRef(new Animated.Value(0)).current;  // Анимация для кнопки

  const { width: windowWidth } = useWindowDimensions();

  // Анимация текста и кнопки
  useEffect(() => {
    // Запуск анимации для текста
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 2000, // Длительность 2 секунды
      useNativeDriver: true,  // Оптимизация через Native Driver
    }).start();

    // Запуск анимации для кнопки
    Animated.timing(fadeButtonAnim, {
      toValue: 1,
      duration: 4000, // Длительность 4 секунды
      useNativeDriver: true,  // Оптимизация через Native Driver
    }).start();
  }, [fadeAnim, fadeButtonAnim]);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.scrollContainer}>
        <ScrollView
          horizontal={true}
          style={styles.scrollViewStyle}
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onScroll={Animated.event(
            [{ nativeEvent: { contentOffset: { x: scrollX } } }],
            { useNativeDriver: false }
          )}
          scrollEventThrottle={1}
        >
          {images.map((image, imageIndex) => (
            <View style={{ width: windowWidth, height: 250 }} key={imageIndex}>
              <ImageBackground source={typeof image === 'string' ? { uri: image } : image} style={styles.card}>
              </ImageBackground>
            </View>
          ))}
        </ScrollView>
        <View style={styles.indicatorContainer}>
          {images.map((image, imageIndex) => {
            const width = scrollX.interpolate({
              inputRange: [
                windowWidth * (imageIndex - 1),
                windowWidth * imageIndex,
                windowWidth * (imageIndex + 1)
              ],
              outputRange: [8, 16, 8],
              extrapolate: "clamp"
            });
            return (
              <Animated.View key={imageIndex} style={[styles.normalDot, { width }]} />
            );
          })}
        </View>
      </View>

      {/* Анимированный текст и кнопка */}
      <Animated.View style={[styles.fadeView, { opacity: fadeAnim }]}>
        <Text style={styles.title}>Brownie recipe</Text>
      </Animated.View>

      <Animated.View style={[styles.fadeView, { opacity: fadeButtonAnim }]}>
        <TouchableOpacity style={styles.button} onPress={() => alert('Button Pressed!')}>
          <Text style={styles.buttonText}>Get Started</Text>
        </TouchableOpacity>
      </Animated.View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center"
  },
  scrollContainer: {
    height: 300,
    alignItems: "center",
    justifyContent: "center"
  },
  card: {
    flex: 1,
    marginVertical: 4,
    marginHorizontal: 16,
    borderRadius: 5,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center"
  },
  normalDot: {
    height: 8,
    width: 8,
    borderRadius: 4,
    backgroundColor: "silver",
    marginHorizontal: 4
  },
  indicatorContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center"
  },
  fadeView: {
    marginVertical: 20
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
  },
  button: {
    backgroundColor: "#8d6253",
    padding: 10,
    borderRadius: 5,
    marginVertical: 10,
    alignItems: "center"
  },
  buttonText: {
    color: "white",
    fontSize: 18,
  }
});

export default App;
